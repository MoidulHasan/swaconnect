// Dependencies


// Module scafoldings
const note = {};

note.create = async (req, res, next) => {

}


// export module
module.exports = note;